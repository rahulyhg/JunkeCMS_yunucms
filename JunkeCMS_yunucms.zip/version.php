<?php
return [
    'yunucms' => [
        'version' => '1.1.5',
        'grant'=>'旗舰版',
        'release' => 0,
        'copyright' => 'www.junke158.com',
    ],
];
