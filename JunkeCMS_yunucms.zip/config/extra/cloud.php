<?php
return [
    'identifier'=>'斯坦姆科（章鱼小思）',
    'grant'=>'旗舰版',
];