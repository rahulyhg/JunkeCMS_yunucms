<?php
error_reporting(E_ERROR | E_PARSE );
return [
    'empty_controller'      => 'Master',
    'default_return_type'   => 'json',
];
?>
