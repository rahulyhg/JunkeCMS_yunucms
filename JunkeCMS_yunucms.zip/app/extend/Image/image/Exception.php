<?php
namespace Image\image;

class Exception extends \RuntimeException
{

}